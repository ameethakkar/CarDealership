//
//  DealershipTableViewCell.swift
//  CoxAutomotive
//
//  Created by Thakkar, Amee on 4/13/19.
//  Copyright © 2019 Thakkar, Amee. All rights reserved.
//

import UIKit

class DealershipTableViewCell: UITableViewCell {

    @IBOutlet weak var dealerNameLabel: UILabel!
    @IBOutlet weak var dealerIdLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
